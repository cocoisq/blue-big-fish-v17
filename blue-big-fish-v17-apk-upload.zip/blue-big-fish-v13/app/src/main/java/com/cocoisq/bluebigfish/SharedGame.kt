package com.cocoisq.bluebigfish

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SharedGame {
    private const val PREFS = "blue_big_fish_game"
    private const val KEY_COUNT = "count"
    private const val KEY_TOTAL = "total"
    private const val KEY_DAY = "day"
    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    @Synchronized private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized fun todayCount(context: Context): Int {
        val p = prefs(context)
        if (p.getString(KEY_DAY, "") != today()) {
            p.edit().putString(KEY_DAY, today()).putInt(KEY_COUNT, 0).apply()
            return 0
        }
        return p.getInt(KEY_COUNT, 0)
    }

    @Synchronized fun totalCount(context: Context): Long = prefs(context).getLong(KEY_TOTAL, 0L)

    @Synchronized fun tap(context: Context): Pair<Int, Long> {
        val p = prefs(context)
        val next = todayCount(context) + 1
        val total = totalCount(context) + 1L
        p.edit().putString(KEY_DAY, today()).putInt(KEY_COUNT, next).putLong(KEY_TOTAL, total).apply()
        return Pair(next, total)
    }
}

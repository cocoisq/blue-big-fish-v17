package com.cocoisq.bluebigfish

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val web = WebView(this)
        web.setBackgroundColor(0xFFEDF3FF.toInt())
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(GameBridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class GameBridge {
        @JavascriptInterface fun getCounts(): String {
            return JSONObject().put("today", SharedGame.todayCount(this@MainActivity))
                .put("total", SharedGame.totalCount(this@MainActivity)).toString()
        }
        @JavascriptInterface fun recordTap(): String {
            val (today, total) = SharedGame.tap(this@MainActivity)
            val widgetPhrase = when {
                today % 1000 == 0 -> "🎆🎇🎆"
                today >= 2000 -> null
                else -> null
            }
            FishWidgetProvider.refreshAll(this@MainActivity, widgetPhrase, true, today)
            return JSONObject().put("today", today).put("total", total).toString()
        }
    }
}
